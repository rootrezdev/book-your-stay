var app = {};
$(function () {

    app = {
        init: function() {
            var config = {
                default_checkin: "02/23/2020", // MM/DD/YYYY format
                default_checkout: "02/25/2020", // MM/DD/YYYY format
                min_checkin: "02/11/2020", // MM/DD/YYYY format
                max_checkout: "03/25/2020", // MM/DD/YYYY format
                submission_url: "https://lodging.bookwesteros.com"
            };
            
            this.initializeEvents(config);
        },
        // event initialization 
        initializeEvents: function(settings) {
            if(settings.default_checkin != "") {
                $('#Checkin').val(settings.default_checkin);
            }

            if(settings.default_checkout != "") {
                $('#Checkout').val(settings.default_checkout);
            }

            if(settings.default_checkin != "" && settings.default_checkout == "") {
                var default_checkin = new Date(settings.default_checkin);
                var default_checkout = new Date(settings.default_checkin);
                default_checkout.setDate(default_checkin.getDate()+1);
                var checkout_dd = default_checkout.getDate();
                var checkout_mm = default_checkout.getMonth()+1;
                var checkout_yyyy = default_checkout.getFullYear();
                if(checkout_dd < 10) 
                {
                    checkout_dd = '0' + checkout_dd;
                } 

                if(checkout_mm < 10) 
                {
                    checkout_mm = '0' + checkout_mm;
                } 
                var checkout_date  = checkout_mm + "/" + checkout_dd + "/" + checkout_yyyy;
                $('#Checkout').val(checkout_date);
                settings.default_checkout = checkout_date;
            }
            
            if(settings.default_checkin != "" && settings.default_checkout != "") {
                var monthArr = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                var defaultCheckin = new Date(settings.default_checkin);
                var defaultCheckout = new Date(settings.default_checkout);
                $('#rootrez_daterangepicker').html(monthArr[defaultCheckin.getMonth()] + ' ' + defaultCheckin.getDate() + ', ' + defaultCheckin.getFullYear() 
                                            + ' &rarr; ' + monthArr[defaultCheckout.getMonth()] + ' ' + defaultCheckout.getDate() + ', ' + defaultCheckout.getFullYear() );
            }

            if(settings.min_checkin == ""){
                var today = new Date();
                var dd = today.getDate();
                var mm = today.getMonth()+1;
                var yyyy = today.getFullYear();
                if(dd < 10) 
                {
                    dd = '0' + dd;
                } 

                if(mm < 10) 
                {
                    mm = '0' + mm;
                } 
                var today_date  = mm + "/" + dd + "/" + yyyy;
                settings.min_checkin = today_date;
            }

            if(settings.max_checkout == ""){
                var today = new Date();
                var dd = today.getDate();
                var mm = today.getMonth()+1;
                if(dd < 10) 
                {
                    dd = '0' + dd;
                } 
                if(mm < 10) 
                {
                    mm = '0' + mm;
                }
                var yyyy = today.getFullYear()+2;
                var today_date  = mm + "/" + dd + "/" + yyyy;
                settings.max_checkout = today_date;
            }        
            
            var dpSettings = {
                "minDate": settings.min_checkin,
                "maxDate": settings.max_checkout,
                "dateLimit":{
                    "days": 28
                },
                "applyClass": '',
                "cancelClass": '',
                "buttonClasses": ''
            };

            $('#rootrez-widget-form #rootrez_daterangepicker').daterangepicker(dpSettings, function(start, end){
                $('#rootrez_daterangepicker').html(start.format('MMM D, YYYY') + ' &rarr; ' + end.format('MMM D, YYYY'));
                $('#Checkin').val(start.format('MM/DD/YYYY'));
                $('#Checkout').val(end.format('MM/DD/YYYY'));

                $.ajax({
                    type:"GET",
                    cache:false,
                    url:settings.api_url+"/publisher/v3.0/discounts/all.json",
                    data:{ checkin : start.format('MM/DD/YYYY'), checkout : end.format('MM/DD/YYYY'), key: settings.publisher_key },
                    success: function (response) {        
                        this.buildDropdown(response,$('#PromoCode'),'Select Offer');
                    }
                });
            });

            if(settings.submission_url != "") {
                $("#rootrez-widget-form").attr('action', settings.submission_url);
            } else {
                $('#rootrez-widget-form button[type="submit"]').attr('disabled','disabled');
            }
        },
        buildDropdown: function(result, dropdown, emptyMessage)
        {
            // Remove current options
            dropdown.html('');
            // Add the empty option with the empty message
            dropdown.append('<option value="">' + emptyMessage + '</option>');
            // Check result isnt empty
            if("data" in result && result.data.length > 0)
            {
                // Loop through each of the results and append the option to the dropdown
                $.each(result.data, function(k, v) {
                    //console.log(v);
                    dropdown.append('<option value="' + v.code + '">' + v.display_string + ' - ' + v.code + '</option>');
                });
                $('#PromoCode').addClass('show');
                $('#PromoCode').removeClass('hide');
            } else {
                $('#PromoCode').addClass('hide');
                $('#PromoCode').removeClass('show');
            }
        }
    }
    app.init();
});